# gargoyle-74 character sheet module for foundryVTT!
# in order to install it right now, manually install via the manifest URL
# you can get the rules set from drivethruRPG at:
# https://www.drivethrurpg.com/product/427259/Gargoyle-74
# contact me at bookofxal@gmail.com
# cheers!
